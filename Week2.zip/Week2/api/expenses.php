<?php
/**
 * Expenses API
 * Handles CRUD operations for expenses
 */
require_once 'BaseAPI.php';

class ExpensesAPI extends BaseAPI {
    /**
     * Process the API request
     */
    public function processRequest() {
        switch ($this->method) {
            case 'GET':
                $this->getExpenses();
                break;
            case 'POST':
                $this->createExpense();
                break;
            case 'PUT':
                $this->updateExpense();
                break;
            case 'DELETE':
                $this->deleteExpense();
                break;
            default:
                $this->sendError('Method not allowed', 405);
                break;
        }
    }
    
    /**
     * Get expenses for a specific month
     */
    private function getExpenses() {
        // Validate request data
        if (!isset($this->requestData['month']) || empty($this->requestData['month'])) {
            $this->sendError('Month parameter is required (format: YYYY-MM)');
        }
        
        $month = $this->requestData['month'];
        
        // Validate month format
        if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
            $this->sendError('Invalid month format. Use YYYY-MM');
        }
        
        try {
            // Get expenses with category information
            $stmt = $this->db->prepare("
                SELECT e.id, e.category_id, c.name as category_name, e.amount, e.description, 
                       e.date, e.payment_method, e.created_at
                FROM expenses e
                JOIN categories c ON e.category_id = c.id
                WHERE DATE_FORMAT(e.date, '%Y-%m') = ?
                ORDER BY e.date DESC, e.created_at DESC
            ");
            $stmt->execute([$month]);
            $expenses = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $this->sendResponse($expenses);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Create a new expense
     */
    private function createExpense() {
        // Validate request data
        if (!isset($this->requestData['category_id']) || empty($this->requestData['category_id'])) {
            $this->sendError('Category ID is required');
        }
        
        if (!isset($this->requestData['amount']) || $this->requestData['amount'] <= 0) {
            $this->sendError('Amount must be greater than 0');
        }
        
        if (!isset($this->requestData['description']) || empty(trim($this->requestData['description']))) {
            $this->sendError('Description is required');
        }
        
        if (!isset($this->requestData['date']) || empty($this->requestData['date'])) {
            $this->sendError('Date is required');
        }
        
        if (!isset($this->requestData['payment_method']) || empty($this->requestData['payment_method'])) {
            $this->sendError('Payment method is required');
        }
        
        $categoryId = $this->requestData['category_id'];
        $amount = floatval($this->requestData['amount']);
        $description = trim($this->requestData['description']);
        $date = $this->requestData['date'];
        $paymentMethod = $this->requestData['payment_method'];
        
        // Validate date format
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            $this->sendError('Invalid date format. Use YYYY-MM-DD');
        }
        
        // Validate payment method
        $validPaymentMethods = ['cash', 'online', 'credit_card', 'debit_card'];
        if (!in_array($paymentMethod, $validPaymentMethods)) {
            $this->sendError('Invalid payment method. Use: ' . implode(', ', $validPaymentMethods));
        }
        
        try {
            // Check if category exists
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM categories WHERE id = ?");
            $stmt->execute([$categoryId]);
            $count = $stmt->fetchColumn();
            
            if ($count === 0) {
                $this->sendError('Category not found', 404);
            }
            
            // Insert new expense
            $stmt = $this->db->prepare("
                INSERT INTO expenses (category_id, amount, description, date, payment_method)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([$categoryId, $amount, $description, $date, $paymentMethod]);
            
            $expenseId = $this->db->lastInsertId();
            
            // Get category name for response
            $stmt = $this->db->prepare("SELECT name FROM categories WHERE id = ?");
            $stmt->execute([$categoryId]);
            $categoryName = $stmt->fetchColumn();
            
            // Return the newly created expense
            $this->sendResponse([
                'id' => $expenseId,
                'category_id' => $categoryId,
                'category_name' => $categoryName,
                'amount' => $amount,
                'description' => $description,
                'date' => $date,
                'payment_method' => $paymentMethod,
                'created_at' => date('Y-m-d H:i:s'),
                'message' => 'Expense created successfully'
            ], 201);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Update an existing expense
     */
    private function updateExpense() {
        // Validate request data
        if (!isset($this->requestData['id']) || empty($this->requestData['id'])) {
            $this->sendError('Expense ID is required');
        }
        
        if (!isset($this->requestData['category_id']) || empty($this->requestData['category_id'])) {
            $this->sendError('Category ID is required');
        }
        
        if (!isset($this->requestData['amount']) || $this->requestData['amount'] <= 0) {
            $this->sendError('Amount must be greater than 0');
        }
        
        if (!isset($this->requestData['description']) || empty(trim($this->requestData['description']))) {
            $this->sendError('Description is required');
        }
        
        if (!isset($this->requestData['date']) || empty($this->requestData['date'])) {
            $this->sendError('Date is required');
        }
        
        if (!isset($this->requestData['payment_method']) || empty($this->requestData['payment_method'])) {
            $this->sendError('Payment method is required');
        }
        
        $id = $this->requestData['id'];
        $categoryId = $this->requestData['category_id'];
        $amount = floatval($this->requestData['amount']);
        $description = trim($this->requestData['description']);
        $date = $this->requestData['date'];
        $paymentMethod = $this->requestData['payment_method'];
        
        // Validate date format
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            $this->sendError('Invalid date format. Use YYYY-MM-DD');
        }
        
        // Validate payment method
        $validPaymentMethods = ['cash', 'online', 'credit_card', 'debit_card'];
        if (!in_array($paymentMethod, $validPaymentMethods)) {
            $this->sendError('Invalid payment method. Use: ' . implode(', ', $validPaymentMethods));
        }
        
        try {
            // Check if expense exists
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM expenses WHERE id = ?");
            $stmt->execute([$id]);
            $count = $stmt->fetchColumn();
            
            if ($count === 0) {
                $this->sendError('Expense not found', 404);
            }
            
            // Check if category exists
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM categories WHERE id = ?");
            $stmt->execute([$categoryId]);
            $count = $stmt->fetchColumn();
            
            if ($count === 0) {
                $this->sendError('Category not found', 404);
            }
            
            // Update expense
            $stmt = $this->db->prepare("
                UPDATE expenses
                SET category_id = ?, amount = ?, description = ?, date = ?, payment_method = ?
                WHERE id = ?
            ");
            $stmt->execute([$categoryId, $amount, $description, $date, $paymentMethod, $id]);
            
            // Get category name for response
            $stmt = $this->db->prepare("SELECT name FROM categories WHERE id = ?");
            $stmt->execute([$categoryId]);
            $categoryName = $stmt->fetchColumn();
            
            // Return success response
            $this->sendResponse([
                'id' => $id,
                'category_id' => $categoryId,
                'category_name' => $categoryName,
                'amount' => $amount,
                'description' => $description,
                'date' => $date,
                'payment_method' => $paymentMethod,
                'message' => 'Expense updated successfully'
            ]);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Delete an expense
     */
    private function deleteExpense() {
        // Validate request data
        if (!isset($this->requestData['id']) || empty($this->requestData['id'])) {
            $this->sendError('Expense ID is required');
        }
        
        $id = $this->requestData['id'];
        
        try {
            // Check if expense exists
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM expenses WHERE id = ?");
            $stmt->execute([$id]);
            $count = $stmt->fetchColumn();
            
            if ($count === 0) {
                $this->sendError('Expense not found', 404);
            }
            
            // Delete the expense
            $stmt = $this->db->prepare("DELETE FROM expenses WHERE id = ?");
            $stmt->execute([$id]);
            
            // Return success response
            $this->sendResponse([
                'message' => 'Expense deleted successfully'
            ]);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        }
    }
}

// Process the request
$api = new ExpensesAPI();
$api->processRequest(); 