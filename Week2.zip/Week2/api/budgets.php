<?php
/**
 * Budgets API
 * Handles CRUD operations for budgets
 */
require_once 'BaseAPI.php';

class BudgetsAPI extends BaseAPI {
    /**
     * Process the API request
     */
    public function processRequest() {
        switch ($this->method) {
            case 'GET':
                $this->getBudgets();
                break;
            case 'POST':
                $this->createBudget();
                break;
            case 'PUT':
                $this->updateBudget();
                break;
            case 'DELETE':
                $this->deleteBudget();
                break;
            default:
                $this->sendError('Method not allowed', 405);
                break;
        }
    }
    
    /**
     * Get all budgets for a specific month
     */
    private function getBudgets() {
        // Validate request data
        if (!isset($this->requestData['month']) || empty($this->requestData['month'])) {
            $this->sendError('Month parameter is required (format: YYYY-MM)');
        }
        
        $month = $this->requestData['month'];
        
        // Validate month format
        if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
            $this->sendError('Invalid month format. Use YYYY-MM');
        }
        
        try {
            // Get budgets with category information
            $stmt = $this->db->prepare("
                SELECT b.id, b.category_id, c.name as category_name, b.amount, b.month
                FROM budgets b
                JOIN categories c ON b.category_id = c.id
                WHERE b.month = ?
                ORDER BY c.name ASC
            ");
            $stmt->execute([$month]);
            $budgets = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $this->sendResponse($budgets);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Create a new budget
     */
    private function createBudget() {
        // Validate request data
        if (!isset($this->requestData['category_id']) || empty($this->requestData['category_id'])) {
            $this->sendError('Category ID is required');
        }
        
        if (!isset($this->requestData['month']) || empty($this->requestData['month'])) {
            $this->sendError('Month is required (format: YYYY-MM)');
        }
        
        // Amount can be 0, so we check if it's set but not if it's empty
        if (!isset($this->requestData['amount'])) {
            $this->sendError('Amount is required');
        }
        
        $categoryId = $this->requestData['category_id'];
        $month = $this->requestData['month'];
        $amount = floatval($this->requestData['amount']);
        
        // Validate month format
        if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
            $this->sendError('Invalid month format. Use YYYY-MM');
        }
        
        try {
            // Check if category exists
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM categories WHERE id = ?");
            $stmt->execute([$categoryId]);
            $count = $stmt->fetchColumn();
            
            if ($count === 0) {
                $this->sendError('Category not found', 404);
            }
            
            // Check if budget already exists for this category and month
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM budgets WHERE category_id = ? AND month = ?");
            $stmt->execute([$categoryId, $month]);
            $count = $stmt->fetchColumn();
            
            if ($count > 0) {
                $this->sendError('Budget already exists for this category and month');
            }
            
            // Insert new budget
            $stmt = $this->db->prepare("INSERT INTO budgets (category_id, amount, month) VALUES (?, ?, ?)");
            $stmt->execute([$categoryId, $amount, $month]);
            
            $budgetId = $this->db->lastInsertId();
            
            // Get category name for response
            $stmt = $this->db->prepare("SELECT name FROM categories WHERE id = ?");
            $stmt->execute([$categoryId]);
            $categoryName = $stmt->fetchColumn();
            
            // Return the newly created budget
            $this->sendResponse([
                'id' => $budgetId,
                'category_id' => $categoryId,
                'category_name' => $categoryName,
                'amount' => $amount,
                'month' => $month,
                'message' => 'Budget created successfully'
            ], 201);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Update an existing budget
     */
    private function updateBudget() {
        // Validate request data
        if (!isset($this->requestData['id']) || empty($this->requestData['id'])) {
            $this->sendError('Budget ID is required');
        }
        
        // Amount can be 0, so we check if it's set but not if it's empty
        if (!isset($this->requestData['amount'])) {
            $this->sendError('Amount is required');
        }
        
        $id = $this->requestData['id'];
        $amount = floatval($this->requestData['amount']);
        
        try {
            // Check if budget exists
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM budgets WHERE id = ?");
            $stmt->execute([$id]);
            $count = $stmt->fetchColumn();
            
            if ($count === 0) {
                $this->sendError('Budget not found', 404);
            }
            
            // Update budget
            $stmt = $this->db->prepare("UPDATE budgets SET amount = ? WHERE id = ?");
            $stmt->execute([$amount, $id]);
            
            // Get updated budget with category information
            $stmt = $this->db->prepare("
                SELECT b.id, b.category_id, c.name as category_name, b.amount, b.month
                FROM budgets b
                JOIN categories c ON b.category_id = c.id
                WHERE b.id = ?
            ");
            $stmt->execute([$id]);
            $budget = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Return success response
            $this->sendResponse([
                'budget' => $budget,
                'message' => 'Budget updated successfully'
            ]);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Delete a budget
     */
    private function deleteBudget() {
        // Validate request data
        if (!isset($this->requestData['id']) || empty($this->requestData['id'])) {
            $this->sendError('Budget ID is required');
        }
        
        $id = $this->requestData['id'];
        
        try {
            // Check if budget exists
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM budgets WHERE id = ?");
            $stmt->execute([$id]);
            $count = $stmt->fetchColumn();
            
            if ($count === 0) {
                $this->sendError('Budget not found', 404);
            }
            
            // Delete the budget
            $stmt = $this->db->prepare("DELETE FROM budgets WHERE id = ?");
            $stmt->execute([$id]);
            
            // Return success response
            $this->sendResponse([
                'message' => 'Budget deleted successfully'
            ]);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        }
    }
}

// Process the request
$api = new BudgetsAPI();
$api->processRequest(); 