<?php
/**
 * Categories API
 * Handles CRUD operations for categories
 */
require_once 'BaseAPI.php';

class CategoriesAPI extends BaseAPI {
    /**
     * Process the API request
     */
    public function processRequest() {
        switch ($this->method) {
            case 'GET':
                $this->getCategories();
                break;
            case 'POST':
                $this->createCategory();
                break;
            case 'PUT':
                $this->updateCategory();
                break;
            case 'DELETE':
                $this->deleteCategory();
                break;
            default:
                $this->sendError('Method not allowed', 405);
                break;
        }
    }
    
    /**
     * Get all categories
     */
    private function getCategories() {
        try {
            $stmt = $this->db->prepare("SELECT * FROM categories ORDER BY name ASC");
            $stmt->execute();
            $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $this->sendResponse($categories);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Create a new category
     */
    private function createCategory() {
        // Validate request data
        if (!isset($this->requestData['name']) || empty(trim($this->requestData['name']))) {
            $this->sendError('Category name is required');
        }
        
        $name = trim($this->requestData['name']);
        
        try {
            // Check if category already exists
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM categories WHERE name = ?");
            $stmt->execute([$name]);
            $count = $stmt->fetchColumn();
            
            if ($count > 0) {
                $this->sendError('Category already exists');
            }
            
            // Insert new category
            $stmt = $this->db->prepare("INSERT INTO categories (name) VALUES (?)");
            $stmt->execute([$name]);
            
            $categoryId = $this->db->lastInsertId();
            
            // Return the newly created category
            $this->sendResponse([
                'id' => $categoryId,
                'name' => $name,
                'message' => 'Category created successfully'
            ], 201);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Update an existing category
     */
    private function updateCategory() {
        // Validate request data
        if (!isset($this->requestData['id']) || empty($this->requestData['id'])) {
            $this->sendError('Category ID is required');
        }
        
        if (!isset($this->requestData['name']) || empty(trim($this->requestData['name']))) {
            $this->sendError('Category name is required');
        }
        
        $id = $this->requestData['id'];
        $name = trim($this->requestData['name']);
        
        try {
            // Check if category exists
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM categories WHERE id = ?");
            $stmt->execute([$id]);
            $count = $stmt->fetchColumn();
            
            if ($count === 0) {
                $this->sendError('Category not found', 404);
            }
            
            // Check if the new name already exists for another category
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM categories WHERE name = ? AND id != ?");
            $stmt->execute([$name, $id]);
            $count = $stmt->fetchColumn();
            
            if ($count > 0) {
                $this->sendError('Another category with this name already exists');
            }
            
            // Update category
            $stmt = $this->db->prepare("UPDATE categories SET name = ? WHERE id = ?");
            $stmt->execute([$name, $id]);
            
            // Return success response
            $this->sendResponse([
                'id' => $id,
                'name' => $name,
                'message' => 'Category updated successfully'
            ]);
        } catch (PDOException $e) {
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Delete a category
     */
    private function deleteCategory() {
        // Validate request data
        if (!isset($this->requestData['id']) || empty($this->requestData['id'])) {
            $this->sendError('Category ID is required');
        }
        
        $id = $this->requestData['id'];
        
        try {
            // Check if category exists
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM categories WHERE id = ?");
            $stmt->execute([$id]);
            $count = $stmt->fetchColumn();
            
            if ($count === 0) {
                $this->sendError('Category not found', 404);
            }
            
            // Check if this is the "Others" category (which should not be deleted)
            $stmt = $this->db->prepare("SELECT name FROM categories WHERE id = ?");
            $stmt->execute([$id]);
            $categoryName = $stmt->fetchColumn();
            
            if (strtolower($categoryName) === 'others') {
                $this->sendError('The "Others" category cannot be deleted');
            }
            
            // Begin transaction
            $this->db->beginTransaction();
            
            // Get the "Others" category ID
            $stmt = $this->db->prepare("SELECT id FROM categories WHERE LOWER(name) = 'others' LIMIT 1");
            $stmt->execute();
            $othersId = $stmt->fetchColumn();
            
            if (!$othersId) {
                // Create "Others" category if it doesn't exist
                $stmt = $this->db->prepare("INSERT INTO categories (name) VALUES ('Others')");
                $stmt->execute();
                $othersId = $this->db->lastInsertId();
            }
            
            // Move all budgets from this category to "Others"
            $stmt = $this->db->prepare("UPDATE budgets SET category_id = ? WHERE category_id = ?");
            $stmt->execute([$othersId, $id]);
            
            // Move all expenses from this category to "Others"
            $stmt = $this->db->prepare("UPDATE expenses SET category_id = ? WHERE category_id = ?");
            $stmt->execute([$othersId, $id]);
            
            // Delete the category
            $stmt = $this->db->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->execute([$id]);
            
            // Commit transaction
            $this->db->commit();
            
            // Return success response
            $this->sendResponse([
                'message' => 'Category deleted successfully. All associated budgets and expenses have been moved to the "Others" category.'
            ]);
        } catch (PDOException $e) {
            // Rollback transaction on error
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            $this->sendError('Database error: ' . $e->getMessage(), 500);
        }
    }
}

// Process the request
$api = new CategoriesAPI();
$api->processRequest(); 