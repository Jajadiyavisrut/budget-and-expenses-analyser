# Budget and Expenses - Week 1

This is the Week 1 implementation of the Budget and Expenses application. This week focuses on setting up the foundation and core functionality of the application.

## Features

- Category management (create, update, delete)
- Responsive design
- Modern UI with Bootstrap 5

## Technologies Used

- HTML5, CSS3, JavaScript
- Bootstrap 5 for UI components
- PHP for backend API
- MySQL for database storage

## Setup

1. Make sure you have a web server with PHP and MySQL installed
2. Import the database schema from `config/init.sql`
3. Update database connection details in `config/database.php`
4. Access the application through your web server

## API Endpoints

- `/api/categories.php` - Manage categories

## Features Implemented in Week 1

- Project setup and structure
- Database schema creation
- Basic UI layout with responsive design
- Month selector with restriction to current and past months
- Category management (list, add, edit, delete)
- Notification system
- Basic API endpoints for categories

## Setup Instructions

1. Place the files in your web server directory (e.g., htdocs for XAMPP)
2. Make sure your MySQL server is running
3. Access the application through your web browser (e.g., http://localhost/Week1/)
4. The application will automatically create the necessary database and tables

## Database Configuration

The database configuration is located in `config/database.php`. By default, it uses the following settings:

- Host: localhost
- Database: finance_manager
- Username: root
- Password: (empty)

You can modify these settings if needed.

## Project Structure

- `index.php`: Main HTML file
- `css/style.css`: CSS styles
- `js/app.js`: JavaScript functionality
- `api/categories.php`: API endpoint for categories
- `config/database.php`: Database configuration
- `config/init.sql`: SQL initialization script

## Week 1 Limitations

- Uses mock data for some functionality
- Budget and expense management will be implemented in Week 2
- Data visualization will be implemented in Week 2

## Next Steps (Week 2)

- Implement budget management
- Implement expense management
- Add data visualization
- Enhance UI/UX 