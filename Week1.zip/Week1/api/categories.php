<?php
header('Content-Type: application/json');

// Include database connection
$pdo = require_once '../config/database.php';

// Get request method
$method = $_SERVER['REQUEST_METHOD'];

// Handle different request methods
switch ($method) {
    case 'GET':
        // Get all categories
        try {
            $stmt = $pdo->query("SELECT * FROM categories ORDER BY name");
            $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($categories);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to fetch categories: ' . $e->getMessage()]);
        }
        break;
        
    case 'POST':
        // Create a new category
        try {
            // Get request body
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Validate input
            if (!isset($data['name']) || empty(trim($data['name']))) {
                http_response_code(400);
                echo json_encode(['error' => 'Category name is required']);
                exit;
            }
            
            // Check if we already have 6 custom categories (plus the default "Others" category)
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM categories WHERE name != 'Others'");
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($result['count'] >= 6) {
                http_response_code(400);
                echo json_encode(['error' => 'Maximum limit of 6 custom categories reached']);
                exit;
            }
            
            // Insert category
            $stmt = $pdo->prepare("INSERT INTO categories (name) VALUES (?)");
            $stmt->execute([$data['name']]);
            
            // Get the new category ID
            $categoryId = $pdo->lastInsertId();
            
            // Return the new category
            $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
            $stmt->execute([$categoryId]);
            $category = $stmt->fetch(PDO::FETCH_ASSOC);
            
            echo json_encode($category);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to create category: ' . $e->getMessage()]);
        }
        break;
        
    case 'PUT':
        // Update a category
        try {
            // Get request body
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Validate input
            if (!isset($data['id']) || !isset($data['name']) || empty(trim($data['name']))) {
                http_response_code(400);
                echo json_encode(['error' => 'Category ID and name are required']);
                exit;
            }
            
            // Update category
            $stmt = $pdo->prepare("UPDATE categories SET name = ? WHERE id = ?");
            $stmt->execute([$data['name'], $data['id']]);
            
            // Check if category was found
            if ($stmt->rowCount() === 0) {
                http_response_code(404);
                echo json_encode(['error' => 'Category not found']);
                exit;
            }
            
            // Return the updated category
            $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
            $stmt->execute([$data['id']]);
            $category = $stmt->fetch(PDO::FETCH_ASSOC);
            
            echo json_encode($category);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to update category: ' . $e->getMessage()]);
        }
        break;
        
    case 'DELETE':
        // Delete a category
        try {
            // Get category ID from query string
            if (!isset($_GET['id'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Category ID is required']);
                exit;
            }
            
            $categoryId = $_GET['id'];
            
            // Check if it's the default category (Others)
            $stmt = $pdo->prepare("SELECT id FROM categories WHERE id = ? AND name = 'Others'");
            $stmt->execute([$categoryId]);
            if ($stmt->fetch()) {
                http_response_code(400);
                echo json_encode(['error' => 'Cannot delete the default category']);
                exit;
            }
            
            // Delete category
            $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->execute([$categoryId]);
            
            // Check if category was found
            if ($stmt->rowCount() === 0) {
                http_response_code(404);
                echo json_encode(['error' => 'Category not found']);
                exit;
            }
            
            echo json_encode(['success' => true, 'message' => 'Category deleted successfully']);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to delete category: ' . $e->getMessage()]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}
?> 