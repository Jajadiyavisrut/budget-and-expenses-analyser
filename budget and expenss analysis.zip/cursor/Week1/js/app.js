/**
 * Budget and Expenses - Week 1
 * Core functionality: Month selector, Categories management
 */

// Global variables
let currentMonth = new Date().toISOString().slice(0, 7); // Format: YYYY-MM
let categories = [];

// API endpoints
const API_ENDPOINTS = {
    CATEGORIES: 'api/categories.php',
};

// Initialize the application
document.addEventListener('DOMContentLoaded', initApp);

function initApp() {
    setupMonthSelector();
    setupCategoryForm();
    setupDirectCategoryInput();
    loadCategories();
}

/**
 * Set up the month selector with current month and restrict future months
 */
function setupMonthSelector() {
    const monthSelector = document.getElementById('monthSelector');
    
    // Set initial value to current month
    monthSelector.value = currentMonth;
    
    // Set max attribute to current month to prevent future selection
    monthSelector.setAttribute('max', currentMonth);
    
    // Add event listener for month change
    monthSelector.addEventListener('change', function() {
        // Validate that selected month is not in the future
        if (this.value > new Date().toISOString().slice(0, 7)) {
            this.value = currentMonth;
            showNotification('Cannot select future months', 'warning');
            return;
        }
        
        currentMonth = this.value;
        showNotification(`Switched to ${new Date(currentMonth + '-01').toLocaleDateString('en-US', {year: 'numeric', month: 'long'})}`, 'info');
        loadCategories();
    });
}

/**
 * Set up the category form submission
 */
function setupCategoryForm() {
    const categoryForm = document.getElementById('categoryForm');
    const categoryModal = new bootstrap.Modal(document.getElementById('categoryModal'));
    
    categoryForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const categoryId = document.getElementById('categoryId').value;
        const categoryName = document.getElementById('categoryName').value.trim();
        
        if (!categoryName) {
            showNotification('Category name is required', 'warning');
            return;
        }
        
        try {
            if (categoryId) {
                // Update existing category
                await updateCategory(categoryId, categoryName);
                showNotification('Category updated successfully', 'success');
            } else {
                // Create new category
                await createCategory(categoryName);
                showNotification('Category created successfully', 'success');
            }
            
            // Reset form and close modal
            categoryForm.reset();
            categoryModal.hide();
            
            // Reload categories
            await loadCategories();
        } catch (error) {
            console.error('Error saving category:', error);
            showNotification(error.message || 'Failed to save category', 'danger');
            
            // Don't close modal if there was an error creating a new category
            if (!categoryId) {
                return;
            }
            
            // Close modal if it was an update
            categoryForm.reset();
            categoryModal.hide();
        }
    });
}

/**
 * Set up the direct category input
 */
function setupDirectCategoryInput() {
    const directCategoryInput = document.getElementById('directCategoryInput');
    const directAddCategoryBtn = document.getElementById('directAddCategoryBtn');
    
    directAddCategoryBtn.addEventListener('click', async function() {
        const categoryName = directCategoryInput.value.trim();
        
        if (!categoryName) {
            showNotification('Category name is required', 'warning');
            return;
        }
        
        try {
            await createCategory(categoryName);
            showNotification('Category created successfully', 'success');
            
            // Clear input field
            directCategoryInput.value = '';
            
            // Reload categories
            await loadCategories();
        } catch (error) {
            console.error('Error creating category:', error);
            showNotification(error.message || 'Failed to create category', 'danger');
        }
    });
    
    // Also allow pressing Enter to add category
    directCategoryInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            directAddCategoryBtn.click();
        }
    });
}

/**
 * Load categories from the API
 */
async function loadCategories() {
    try {
        const response = await fetchData(API_ENDPOINTS.CATEGORIES);
        categories = response;
        updateCategoriesList();
        
        // Update category limit info
        const customCategories = categories.filter(cat => cat.name.toLowerCase() !== 'others').length;
        const remainingSlots = 6 - customCategories;
        const limitInfoElement = document.querySelector('.text-muted.small.mb-3');
        if (limitInfoElement) {
            limitInfoElement.textContent = `Note: You can add up to 6 custom categories. ${remainingSlots} slot${remainingSlots !== 1 ? 's' : ''} remaining. "Others" is a default category.`;
        }
        
        // Disable add buttons if limit reached
        const directAddCategoryBtn = document.getElementById('directAddCategoryBtn');
        const directCategoryInput = document.getElementById('directCategoryInput');
        
        if (remainingSlots <= 0) {
            directAddCategoryBtn.disabled = true;
            directCategoryInput.disabled = true;
            directCategoryInput.placeholder = 'Maximum categories reached';
        } else {
            directAddCategoryBtn.disabled = false;
            directCategoryInput.disabled = false;
            directCategoryInput.placeholder = 'Enter category name';
        }
    } catch (error) {
        console.error('Error loading categories:', error);
        showNotification('Failed to load categories', 'danger');
    }
}

/**
 * Update the categories list in the UI
 */
function updateCategoriesList() {
    const categoriesList = document.getElementById('categoriesList');
    categoriesList.innerHTML = '';
    
    if (categories.length === 0) {
        categoriesList.innerHTML = '<div class="text-center text-muted">No categories found</div>';
        return;
    }
    
    categories.forEach(category => {
        const item = document.createElement('div');
        item.className = 'list-group-item';
        
        const isOthers = category.name.toLowerCase() === 'others';
        
        item.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
                <span>${category.name}</span>
                <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-primary edit-category-btn" data-id="${category.id}" ${isOthers ? 'disabled' : ''}>
                        Edit
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-danger delete-category-btn" data-id="${category.id}" ${isOthers ? 'disabled' : ''}>
                        Delete
                    </button>
                </div>
            </div>
        `;
        
        // Add event listeners for edit and delete buttons
        const editBtn = item.querySelector('.edit-category-btn');
        const deleteBtn = item.querySelector('.delete-category-btn');
        
        editBtn.addEventListener('click', function() {
            const categoryId = this.getAttribute('data-id');
            const category = categories.find(c => c.id == categoryId);
            
            if (category) {
                // Set form values and modal title for editing
                document.getElementById('categoryId').value = category.id;
                document.getElementById('categoryName').value = category.name;
                document.getElementById('categoryModalTitle').textContent = 'Edit Category';
                
                // Show modal
                const categoryModal = new bootstrap.Modal(document.getElementById('categoryModal'));
                categoryModal.show();
            }
        });
        
        deleteBtn.addEventListener('click', async function() {
            const categoryId = this.getAttribute('data-id');
            const category = categories.find(c => c.id == categoryId);
            
            if (category && confirm(`Are you sure you want to delete "${category.name}"?`)) {
                try {
                    await deleteCategory(categoryId);
                    showNotification('Category deleted successfully', 'success');
                    await loadCategories();
                } catch (error) {
                    console.error('Error deleting category:', error);
                    showNotification(error.message || 'Failed to delete category', 'danger');
                }
            }
        });
        
        categoriesList.appendChild(item);
    });
}

/**
 * Create a new category
 */
async function createCategory(name) {
    return fetchData(API_ENDPOINTS.CATEGORIES, {
        method: 'POST',
        body: JSON.stringify({ name })
    });
}

/**
 * Update an existing category
 */
async function updateCategory(id, name) {
    return fetchData(API_ENDPOINTS.CATEGORIES, {
        method: 'PUT',
        body: JSON.stringify({ id, name })
    });
}

/**
 * Delete a category
 */
async function deleteCategory(id) {
    return fetchData(`${API_ENDPOINTS.CATEGORIES}?id=${id}`, {
        method: 'DELETE'
    });
}

/**
 * Show a notification message
 */
function showNotification(message, type = 'success') {
    const notificationsContainer = document.getElementById('notifications');
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show`;
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Add to container
    notificationsContainer.appendChild(notification);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
    
    // Add click event to close button
    const closeBtn = notification.querySelector('.btn-close');
    closeBtn.addEventListener('click', () => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    });
}

/**
 * Fetch data from the API
 */
async function fetchData(endpoint, options = {}) {
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    
    const fetchOptions = { ...defaultOptions, ...options };
    
    try {
        const response = await fetch(endpoint, fetchOptions);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || `HTTP error! status: ${response.status}`);
        }
        
        return data;
    } catch (error) {
        console.error('Fetch error:', error);
        throw error;
    }
} 