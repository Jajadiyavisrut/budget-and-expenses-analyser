<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget Tracker - Week 1</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="../css/style.css" rel="stylesheet">
    
    <!-- Additional styles to fix horizontal line issues -->
    <style>
        body, html {
            overflow-x: hidden;
            width: 100%;
            margin: 0;
            padding: 0;
        }
        
        .container-fluid, .container {
            padding-left: 0;
            padding-right: 0;
            border: none;
        }
        
        .row {
            margin-left: 0;
            margin-right: 0;
        }
        
        /* Remove any horizontal borders */
        * {
            border-left: none !important;
            border-right: none !important;
        }
    </style>
</head>
<body class="bg-dark text-white">
    <!-- Header with software development and ID -->
    <div class="container-fluid py-2 mb-4">
        <div class="row">
            <div class="col-12">
                <div class="bg-dark-glass py-2 px-4 rounded-pill shadow-lg mx-auto" style="max-width: 90%; transform: translateY(10px);">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="m-0 fw-bold" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">Software Development</h5>
                        <h5 class="m-0 fw-bold" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">226120316021</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container py-4">
        <!-- Header with month selector -->
        <header class="text-center mb-5">
            <h1>Budget Tracker</h1>
            <div class="month-selector-container">
                <small class="text-white mb-2 d-block">Select month (current or past only)</small>
                <input type="month" id="monthSelector" class="form-control mb-4">
            </div>
        </header>

        <!-- Notifications -->
        <div id="notifications" class="position-fixed top-0 start-50 translate-middle-x mt-3" style="z-index: 1050;"></div>

        <div class="row g-4">
            <!-- Categories Section -->
            <div class="col-md-12">
                <div class="card bg-dark-glass">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h2 class="card-title">Categories</h2>
                        </div>
                        
                        <!-- Direct input field for adding categories -->
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" id="directCategoryInput" placeholder="Enter category name">
                            <button class="btn btn-primary" id="directAddCategoryBtn">Add</button>
                        </div>
                        <div class="text-muted small mb-3">
                            Note: You can add up to 6 custom categories. "Others" is a default category.
                        </div>
                        
                        <div id="categoriesList" class="list-group"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Category Modal -->
    <div class="modal fade" id="categoryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content bg-dark-glass">
                <div class="modal-header">
                    <h5 class="modal-title" id="categoryModalTitle">Add Category</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="categoryForm">
                        <input type="hidden" id="categoryId">
                        <div class="mb-3">
                            <label for="categoryName" class="form-label">Category Name</label>
                            <input type="text" class="form-control" id="categoryName" placeholder="Enter category name" required>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn btn-outline-secondary me-2" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <footer class="mt-5 py-3 text-center">
        <div class="container">
            <p class="text-muted fw-bold" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; border: none;">Budget & Expenses Analysis © 2025 | Made by Visrut</p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script src="js/app.js"></script>
</body>
</html> 