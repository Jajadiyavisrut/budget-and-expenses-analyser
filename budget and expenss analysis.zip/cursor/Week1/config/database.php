<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'finance_manager');
define('DB_USER', 'root');
define('DB_PASS', '');

// Check if database exists, create if not
try {
    $checkConnection = new PDO(
        "mysql:host=" . DB_HOST,
        DB_USER,
        DB_PASS,
        array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
    );
    
    // Check if database exists
    $stmt = $checkConnection->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '" . DB_NAME . "'");
    if (!$stmt->fetch()) {
        // Create database
        $checkConnection->exec("CREATE DATABASE IF NOT EXISTS " . DB_NAME);
    }
    
    // Connect to the database
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
        DB_USER,
        DB_PASS,
        array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
    );
    
    return $pdo;
} catch(PDOException $e) {
    // Return error as JSON
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}
?> 