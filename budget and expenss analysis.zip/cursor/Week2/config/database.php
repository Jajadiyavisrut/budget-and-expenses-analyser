<?php
/**
 * Database Connection
 */

// Database configuration
$host = 'localhost';
$db_name = 'budget_tracker';
$username = 'root';
$password = '';
$charset = 'utf8mb4';

// DSN (Data Source Name)
$dsn = "mysql:host=$host;dbname=$db_name;charset=$charset";

// PDO options
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

// Create PDO instance
try {
    $conn = new PDO($dsn, $username, $password, $options);
} catch (PDOException $e) {
    // If connection fails, display error message
    die("Connection failed: " . $e->getMessage());
}

// Function to check if tables exist and create them if they don't
function ensureTablesExist($conn) {
    try {
        // Check if categories table exists
        $result = $conn->query("SHOW TABLES LIKE 'categories'");
        if ($result->rowCount() === 0) {
            // Create categories table
            $conn->exec("
                CREATE TABLE categories (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(50) NOT NULL UNIQUE
                )
            ");
            
            // Insert default category
            $conn->exec("INSERT INTO categories (name) VALUES ('Others')");
        }
        
        // Check if budgets table exists
        $result = $conn->query("SHOW TABLES LIKE 'budgets'");
        if ($result->rowCount() === 0) {
            // Create budgets table
            $conn->exec("
                CREATE TABLE budgets (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    category_id INT NOT NULL,
                    amount DECIMAL(10, 2) NOT NULL DEFAULT 0,
                    month VARCHAR(7) NOT NULL,
                    FOREIGN KEY (category_id) REFERENCES categories(id),
                    UNIQUE KEY (category_id, month)
                )
            ");
        }
        
        // Check if expenses table exists
        $result = $conn->query("SHOW TABLES LIKE 'expenses'");
        if ($result->rowCount() === 0) {
            // Create expenses table
            $conn->exec("
                CREATE TABLE expenses (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    category_id INT NOT NULL,
                    amount DECIMAL(10, 2) NOT NULL,
                    description TEXT NOT NULL,
                    date DATE NOT NULL,
                    payment_method ENUM('cash', 'online', 'credit_card', 'debit_card') NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (category_id) REFERENCES categories(id)
                )
            ");
        }
        
        return true;
    } catch (PDOException $e) {
        die("Table creation failed: " . $e->getMessage());
    }
}

// Ensure tables exist
ensureTablesExist($conn); 