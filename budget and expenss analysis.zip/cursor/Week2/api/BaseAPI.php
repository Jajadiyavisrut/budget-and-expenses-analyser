<?php
/**
 * Base API class for handling common API functionality
 */
class BaseAPI {
    protected $db;
    protected $method;
    protected $requestData;
    
    /**
     * Constructor
     */
    public function __construct() {
        // Include database connection from main project
        require_once '../../config/database.php';
        $this->db = $conn;
        
        // Set request method
        $this->method = $_SERVER['REQUEST_METHOD'];
        
        // Get request data
        $this->requestData = $this->getRequestData();
        
        // Handle CORS
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
        header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
        
        // Handle preflight requests
        if ($this->method === 'OPTIONS') {
            http_response_code(200);
            exit;
        }
    }
    
    /**
     * Get request data based on request method
     */
    protected function getRequestData() {
        if ($this->method === 'GET') {
            return $_GET;
        }
        
        $data = json_decode(file_get_contents("php://input"), true);
        return $data ? $data : $_POST;
    }
    
    /**
     * Send JSON response
     */
    protected function sendResponse($data, $statusCode = 200) {
        http_response_code($statusCode);
        echo json_encode($data);
        exit;
    }
    
    /**
     * Send error response
     */
    protected function sendError($message, $statusCode = 400) {
        $this->sendResponse(['error' => $message], $statusCode);
    }
} 