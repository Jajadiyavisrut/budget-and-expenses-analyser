/**
 * Budget and Expenses - Week 2
 * Core functionality: Categories, Budgets, Expenses, and Budget vs Actual Chart
 */

// Constants
const API_ENDPOINTS = {
    CATEGORIES: '../api/categories.php',
    BUDGETS: '../api/budgets.php',
    EXPENSES: '../api/expenses.php'
};

const PAYMENT_METHODS = {
    cash: { label: 'Cash', class: 'payment-cash' },
    online: { label: 'Online', class: 'payment-online' },
    credit_card: { label: 'Credit Card', class: 'payment-credit' },
    debit_card: { label: 'Debit Card', class: 'payment-debit' }
};

// State management
let currentMonth = '2025-03'; // Default month to match database data
let categories = [];
let budgets = [];
let expenses = [];
let lastAddedBudgetId = null;
let lastAddedExpenseId = null;
let notificationTimeout = null;

// Add global variable to store chart instance
let budgetVsActualChartInstance = null;

// DOM Elements
const categoryForm = document.getElementById('categoryForm');
const categoryNameInput = document.getElementById('categoryNameInput');
const categorySubmitBtn = document.getElementById('categorySubmitBtn');
const cancelEditBtn = document.getElementById('cancelEditBtn');
const categoryList = document.getElementById('categoryList');
const editCategoryId = document.getElementById('editCategoryId');

const budgetForm = document.getElementById('budgetForm');
const budgetCategorySelect = document.getElementById('budgetCategorySelect');
const budgetAmountInput = document.getElementById('budgetAmountInput');
const budgetSubmitBtn = document.getElementById('budgetSubmitBtn');
const cancelBudgetEditBtn = document.getElementById('cancelBudgetEditBtn');
const budgetList = document.getElementById('budgetList');
const editBudgetId = document.getElementById('editBudgetId');
const editBudgetControls = document.getElementById('editBudgetControls');

const expenseForm = document.getElementById('expenseForm');
const expenseCategorySelect = document.getElementById('expenseCategorySelect');
const expenseAmountInput = document.getElementById('expenseAmountInput');
const expenseDescriptionInput = document.getElementById('expenseDescriptionInput');
const expenseDateInput = document.getElementById('expenseDateInput');
const expensePaymentMethodSelect = document.getElementById('expensePaymentMethodSelect');
const expenseSubmitBtn = document.getElementById('expenseSubmitBtn');
const cancelExpenseEditBtn = document.getElementById('cancelExpenseEditBtn');
const editExpenseId = document.getElementById('editExpenseId');
const editExpenseControls = document.getElementById('editExpenseControls');
const dateRestrictionMsg = document.getElementById('dateRestrictionMsg');

const monthSelector = document.getElementById('monthSelector');

// Initialize the application
async function initializeApp() {
    try {
        // Setup month selector
        setupMonthSelector();
        
        // Load data
        await loadCategories();
        await loadBudgets();
        await loadExpenses();
        
        // Setup forms
        setupCategoryForm();
        setupBudgetForm();
        setupExpenseForm();
        
        // Initialize charts
        updateBudgetVsActualChart();
        
        // Show welcome notification
        showNotification('Welcome to Budget Tracker!', 'info');
    } catch (error) {
        console.error('Error initializing app:', error);
        showNotification('Failed to initialize application. Please try refreshing the page.', 'danger');
    }
}

// Setup month selector
function setupMonthSelector() {
    // Set initial value
    monthSelector.value = currentMonth;
    
    // Add event listener for month changes
    monthSelector.addEventListener('change', async (e) => {
        const selectedMonth = e.target.value;
        
        // Update current month and reload data
        currentMonth = selectedMonth;
        try {
            await loadBudgets();
            await loadExpenses();
            
            // Update expense form date restrictions
            setupExpenseForm();
            
            // Show notification about the month change
            showNotification(`Switched to ${new Date(currentMonth + '-01').toLocaleDateString('en-US', {year: 'numeric', month: 'long'})}`, 'info');
        } catch (error) {
            showNotification('Failed to load data for the selected month', 'danger');
        }
    });
}

// API Functions
async function loadCategories() {
    try {
        const response = await fetch(API_ENDPOINTS.CATEGORIES);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        categories = await response.json();
        renderCategories();
        updateCategorySelects();
        return categories;
    } catch (error) {
        console.error('Error loading categories:', error);
        showNotification('Failed to load categories', 'danger');
        throw error;
    }
}

async function loadBudgets() {
    try {
        const response = await fetch(`${API_ENDPOINTS.BUDGETS}?month=${currentMonth}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        budgets = await response.json();
        renderBudgets();
        return budgets;
    } catch (error) {
        console.error('Error loading budgets:', error);
        showNotification('Failed to load budgets', 'danger');
        throw error;
    }
}

async function loadExpenses() {
    try {
        const response = await fetch(`${API_ENDPOINTS.EXPENSES}?month=${currentMonth}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        expenses = await response.json();
        updateBudgetVsActualChart();
        return expenses;
    } catch (error) {
        console.error('Error loading expenses:', error);
        showNotification('Failed to load expenses', 'danger');
        throw error;
    }
}

// Category Functions
function setupCategoryForm() {
    categoryForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const categoryName = categoryNameInput.value.trim();
        if (!categoryName) {
            showNotification('Category name is required', 'warning');
            return;
        }
        
        const isEditing = editCategoryId.value !== '';
        
        try {
            if (isEditing) {
                // Update existing category
                const response = await fetch(API_ENDPOINTS.CATEGORIES, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id: editCategoryId.value,
                        name: categoryName
                    })
                });
                
                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
                }
                
                const data = await response.json();
                showNotification(data.message || 'Category updated successfully', 'success');
            } else {
                // Create new category
                const response = await fetch(API_ENDPOINTS.CATEGORIES, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        name: categoryName
                    })
                });
                
                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
                }
                
                const data = await response.json();
                showNotification(data.message || 'Category created successfully', 'success');
            }
            
            // Reset form and reload categories
            resetCategoryForm();
            await loadCategories();
        } catch (error) {
            console.error('Error saving category:', error);
            showNotification(error.message || 'Failed to save category', 'danger');
        }
    });
    
    cancelEditBtn.addEventListener('click', resetCategoryForm);
}

function resetCategoryForm() {
    categoryNameInput.value = '';
    editCategoryId.value = '';
    categorySubmitBtn.textContent = 'Add';
    cancelEditBtn.classList.add('d-none');
}

function renderCategories() {
    categoryList.innerHTML = '';
    
    if (categories.length === 0) {
        categoryList.innerHTML = '<div class="text-center text-muted">No categories found</div>';
        return;
    }
    
    categories.forEach(category => {
        const item = document.createElement('div');
        item.className = 'list-group-item';
        
        const isOthers = category.name.toLowerCase() === 'others';
        
        item.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
                <span>${category.name}</span>
                <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-primary edit-category-btn" data-id="${category.id}" data-name="${category.name}" ${isOthers ? 'disabled' : ''}>
                        Edit
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-danger delete-category-btn" data-id="${category.id}" ${isOthers ? 'disabled' : ''}>
                        Delete
                    </button>
                </div>
            </div>
        `;
        
        // Add event listeners
        const editBtn = item.querySelector('.edit-category-btn');
        const deleteBtn = item.querySelector('.delete-category-btn');
        
        editBtn.addEventListener('click', () => {
            editCategoryId.value = category.id;
            categoryNameInput.value = category.name;
            categorySubmitBtn.textContent = 'Update';
            cancelEditBtn.classList.remove('d-none');
            categoryNameInput.focus();
        });
        
        deleteBtn.addEventListener('click', async () => {
            if (confirm(`Are you sure you want to delete "${category.name}"? All associated budgets and expenses will be moved to the "Others" category.`)) {
                try {
                    const response = await fetch(API_ENDPOINTS.CATEGORIES, {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            id: category.id
                        })
                    });
                    
                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
                    }
                    
                    const data = await response.json();
                    showNotification(data.message || 'Category deleted successfully', 'success');
                    
                    // Reload data
                    await loadCategories();
                    await loadBudgets();
                    await loadExpenses();
                } catch (error) {
                    console.error('Error deleting category:', error);
                    showNotification(error.message || 'Failed to delete category', 'danger');
                }
            }
        });
        
        categoryList.appendChild(item);
    });
}

function updateCategorySelects() {
    // Clear existing options
    budgetCategorySelect.innerHTML = '<option value="">Select category</option>';
    expenseCategorySelect.innerHTML = '<option value="">Select category</option>';
    
    // Add options for each category
    categories.forEach(category => {
        const budgetOption = document.createElement('option');
        budgetOption.value = category.id;
        budgetOption.textContent = category.name;
        budgetCategorySelect.appendChild(budgetOption);
        
        const expenseOption = document.createElement('option');
        expenseOption.value = category.id;
        expenseOption.textContent = category.name;
        expenseCategorySelect.appendChild(expenseOption);
    });
}

// Budget Functions
function setupBudgetForm() {
    budgetForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const categoryId = budgetCategorySelect.value;
        const amount = parseFloat(budgetAmountInput.value) || 0;
        
        if (!categoryId) {
            showNotification('Please select a category', 'warning');
            return;
        }
        
        const isEditing = editBudgetId.value !== '';
        
        try {
            if (isEditing) {
                // Update existing budget
                const response = await fetch(API_ENDPOINTS.BUDGETS, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id: editBudgetId.value,
                        amount: amount
                    })
                });
                
                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
                }
                
                const data = await response.json();
                showNotification(data.message || 'Budget updated successfully', 'success');
                lastAddedBudgetId = data.budget?.id || null;
            } else {
                // Create new budget
                const response = await fetch(API_ENDPOINTS.BUDGETS, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        category_id: categoryId,
                        amount: amount,
                        month: currentMonth
                    })
                });
                
                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
                }
                
                const data = await response.json();
                showNotification(data.message || 'Budget created successfully', 'success');
                lastAddedBudgetId = data.id || null;
            }
            
            // Reset form and reload budgets
            resetBudgetForm();
            await loadBudgets();
            await updateBudgetVsActualChart();
        } catch (error) {
            console.error('Error saving budget:', error);
            showNotification(error.message || 'Failed to save budget', 'danger');
        }
    });
    
    cancelBudgetEditBtn.addEventListener('click', resetBudgetForm);
}

function resetBudgetForm() {
    budgetCategorySelect.value = '';
    budgetAmountInput.value = '';
    editBudgetId.value = '';
    budgetSubmitBtn.textContent = 'Set';
    editBudgetControls.classList.add('d-none');
}

function renderBudgets() {
    budgetList.innerHTML = '';
    
    if (budgets.length === 0) {
        budgetList.innerHTML = '<div class="text-center text-muted">No budgets found for this month</div>';
        return;
    }
    
    budgets.forEach(budget => {
        const item = document.createElement('div');
        item.className = 'list-group-item';
        
        if (lastAddedBudgetId && budget.id == lastAddedBudgetId) {
            item.classList.add('newly-added-budget');
            // Clear the last added ID after highlighting
            setTimeout(() => {
                lastAddedBudgetId = null;
            }, 2000);
        }
        
        item.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
                <span>${budget.category_name}</span>
                <div>
                    <span class="badge bg-primary rounded-pill me-2">₹${parseFloat(budget.amount).toFixed(2)}</span>
                    <div class="btn-group">
                        <button type="button" class="btn btn-sm btn-outline-primary edit-budget-btn" data-id="${budget.id}" data-category="${budget.category_id}" data-amount="${budget.amount}">
                            Edit
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-danger delete-budget-btn" data-id="${budget.id}">
                            Delete
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        // Add event listeners
        const editBtn = item.querySelector('.edit-budget-btn');
        const deleteBtn = item.querySelector('.delete-budget-btn');
        
        editBtn.addEventListener('click', () => {
            editBudgetId.value = budget.id;
            budgetCategorySelect.value = budget.category_id;
            budgetAmountInput.value = budget.amount;
            budgetSubmitBtn.textContent = 'Update';
            editBudgetControls.classList.remove('d-none');
            budgetAmountInput.focus();
        });
        
        deleteBtn.addEventListener('click', async () => {
            if (confirm(`Are you sure you want to delete the budget for "${budget.category_name}"?`)) {
                try {
                    const response = await fetch(API_ENDPOINTS.BUDGETS, {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            id: budget.id
                        })
                    });
                    
                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
                    }
                    
                    const data = await response.json();
                    showNotification(data.message || 'Budget deleted successfully', 'success');
                    
                    // Reload budgets
                    await loadBudgets();
                    await updateBudgetVsActualChart();
                } catch (error) {
                    console.error('Error deleting budget:', error);
                    showNotification(error.message || 'Failed to delete budget', 'danger');
                }
            }
        });
        
        budgetList.appendChild(item);
    });
}

// Expense Functions
function setupExpenseForm() {
    // Set default date to today
    const today = new Date();
    expenseDateInput.value = today.toISOString().slice(0, 10);
    
    // Set date input restrictions
    const firstDay = new Date(currentMonth + '-01');
    const lastDay = new Date(firstDay.getFullYear(), firstDay.getMonth() + 1, 0);
    
    expenseDateInput.min = firstDay.toISOString().slice(0, 10);
    expenseDateInput.max = lastDay.toISOString().slice(0, 10);
    
    // Update date restriction message
    const monthName = firstDay.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    dateRestrictionMsg.textContent = `Date must be within ${monthName}`;
    
    expenseForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const categoryId = expenseCategorySelect.value;
        const amount = parseFloat(expenseAmountInput.value);
        const description = expenseDescriptionInput.value.trim();
        const date = expenseDateInput.value;
        const paymentMethod = expensePaymentMethodSelect.value;
        
        if (!categoryId) {
            showNotification('Please select a category', 'warning');
            return;
        }
        
        if (!amount || amount <= 0) {
            showNotification('Amount must be greater than 0', 'warning');
            return;
        }
        
        if (!description) {
            showNotification('Description is required', 'warning');
            return;
        }
        
        if (!date) {
            showNotification('Date is required', 'warning');
            return;
        }
        
        if (!paymentMethod) {
            showNotification('Payment method is required', 'warning');
            return;
        }
        
        // Check if date is within the selected month
        const expenseMonth = date.slice(0, 7);
        if (expenseMonth !== currentMonth) {
            showNotification(`Date must be within ${monthName}`, 'warning');
            return;
        }
        
        const isEditing = editExpenseId.value !== '';
        
        try {
            if (isEditing) {
                // Update existing expense
                const response = await fetch(API_ENDPOINTS.EXPENSES, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id: editExpenseId.value,
                        category_id: categoryId,
                        amount: amount,
                        description: description,
                        date: date,
                        payment_method: paymentMethod
                    })
                });
                
                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
                }
                
                const data = await response.json();
                showNotification(data.message || 'Expense updated successfully', 'success');
            } else {
                // Create new expense
                const response = await fetch(API_ENDPOINTS.EXPENSES, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        category_id: categoryId,
                        amount: amount,
                        description: description,
                        date: date,
                        payment_method: paymentMethod
                    })
                });
                
                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
                }
                
                const data = await response.json();
                showNotification(data.message || 'Expense created successfully', 'success');
            }
            
            // Reset form and reload expenses
            resetExpenseForm();
            await loadExpenses();
            await updateBudgetVsActualChart();
        } catch (error) {
            console.error('Error saving expense:', error);
            showNotification(error.message || 'Failed to save expense', 'danger');
        }
    });
    
    cancelExpenseEditBtn.addEventListener('click', resetExpenseForm);
}

function resetExpenseForm() {
    expenseCategorySelect.value = '';
    expenseAmountInput.value = '';
    expenseDescriptionInput.value = '';
    // Reset date to today
    const today = new Date();
    expenseDateInput.value = today.toISOString().slice(0, 10);
    expensePaymentMethodSelect.value = '';
    editExpenseId.value = '';
    expenseSubmitBtn.textContent = 'Add Expense';
    editExpenseControls.classList.add('d-none');
}

// Chart Functions
function updateBudgetVsActualChart() {
    const ctx = document.getElementById('budgetVsActualChart').getContext('2d');
    
    // Calculate total expenses by category
    const expensesByCategory = {};
    expenses.forEach(expense => {
        if (!expensesByCategory[expense.category_id]) {
            expensesByCategory[expense.category_id] = 0;
        }
        expensesByCategory[expense.category_id] += parseFloat(expense.amount);
    });
    
    // Prepare data for chart
    const chartData = {
        labels: [],
        budgetData: [],
        expenseData: []
    };
    
    // Add data for each budget
    budgets.forEach(budget => {
        chartData.labels.push(budget.category_name);
        chartData.budgetData.push(parseFloat(budget.amount));
        chartData.expenseData.push(expensesByCategory[budget.category_id] || 0);
    });
    
    // If there's no data, add a placeholder
    if (chartData.labels.length === 0) {
        chartData.labels = ['No data'];
        chartData.budgetData = [0];
        chartData.expenseData = [0];
    }
    
    // Destroy existing chart if it exists
    if (budgetVsActualChartInstance) {
        budgetVsActualChartInstance.destroy();
    }
    
    // Create new chart
    budgetVsActualChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartData.labels,
            datasets: [
                {
                    label: 'Budget',
                    data: chartData.budgetData,
                    backgroundColor: 'rgba(74, 144, 226, 0.7)',
                    borderColor: 'rgba(74, 144, 226, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Actual Spending',
                    data: chartData.expenseData,
                    backgroundColor: 'rgba(255, 99, 132, 0.7)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#ffffff',
                        callback: function(value) {
                            return '₹' + value;
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#ffffff'
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: '#ffffff'
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ₹' + context.raw.toFixed(2);
                        }
                    }
                }
            }
        }
    });
}

// Utility Functions
function showNotification(message, type = 'info') {
    const notificationContainer = document.getElementById('notificationContainer');
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show`;
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Add to container
    notificationContainer.appendChild(notification);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
    
    // Add click event to close button
    const closeBtn = notification.querySelector('.btn-close');
    closeBtn.addEventListener('click', () => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    });
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', initializeApp); 